// Server Node senza dipendenze: serve la cartella public/ e sceglie la lingua dal browser.
// Uso: node server.js   (porta predefinita 3000, oppure PORT=8080 node server.js)
const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, 'public');
const PORT = process.env.PORT || 3000;
const LANGS = ['it', 'en', 'fr', 'de', 'es', 'zh', 'ar'];
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon'
};

function pickLang(header) {
  const wanted = String(header || '').split(',').map((s) => s.trim().slice(0, 2).toLowerCase());
  return wanted.find((l) => LANGS.includes(l)) || 'it';
}

http.createServer((req, res) => {
  let url;
  try { url = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
  catch { res.writeHead(400); return res.end('Bad request'); }

  if (url === '/') {
    res.writeHead(302, { Location: `/${pickLang(req.headers['accept-language'])}/index.html` });
    return res.end();
  }
  if (LANGS.includes(url.replace(/\//g, ''))) url = `/${url.replace(/\//g, '')}/index.html`;

  const file = path.normalize(path.join(ROOT, url));
  if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end('Forbidden'); }

  fs.readFile(file, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end('<h1>404</h1><p><a href="/">Leonardo Guasqui</a></p>');
    }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream' });
    res.end(data);
  });
}).listen(PORT, () => console.log(`Sito su http://localhost:${PORT}`));
