module.exports = {
  lang: 'en', dir: 'ltr', label: 'EN', name: 'English',
  nav: { home: 'Home', classes: 'Classes & prices', sheet: 'Tech pack', process: 'How I work', software: 'Software', contact: 'Contact' },
  menu: 'Menu',
  brandSub: 'Pattern making',
  titles: { home: 'Pattern making for bags and small leather goods', classes: 'Difficulty classes and prices', sheet: 'The tech pack I need', process: 'How I work', software: 'Leonardo Pattern Design', contact: 'Contact' },
  metaDesc: 'Freelance pattern maker for bags and small leather goods: cutting-ready patterns, difficulty classes from A to H, delivery in one week.',
  ctaQuote: 'Request a quote',
  mailSubject: 'Pattern making quote request',
  footerLoc: 'Leonardo Guasqui · Montespertoli, Tuscany',
  footerNote: 'Prices excluding VAT · © 2026',
  home: {
    eyebrow: 'Freelance pattern maker · Bags and small leather goods',
    h1: 'Cutting-ready patterns, with a clear price before we start.',
    lead: 'Since 2017 I have worked on sampling and industrialisation for a Tuscan luxury leather goods manufacturer. Every bag is classified from A to H by complexity: you know straight away what it costs and when it arrives.',
    seeClasses: 'See the classes',
    stats: [['1 week', 'delivery the following Monday'], ['8 classes', 'A to H, fixed price per class'], ['DWG · DXF · PDF', 'no software to buy']],
    deliverH: 'What I deliver',
    deliver: [
      ['Complete patterns', 'Every component: leather, lining, reinforcements and interior, with seam allowances and notches, ready for cutting.'],
      ['Consumption and BOM', 'On request, material consumption and the bill of materials for the model, to plan materials and costs.'],
      ['Ready-to-use files', 'DWG/DXF and PDF, which open in any CAD viewer, including free ones. Print them at 1:1 scale on a printer or plotter.']
    ],
    nextH: 'Where to start',
    next: [
      ['Find your model’s class', 'Eight levels of complexity, each with its own price.'],
      ['Prepare the tech pack', 'The views and measurements I need, with real examples.'],
      ['Read how I work', 'Timing, payment in two instalments and delivered files.']
    ],
    open: 'Open'
  },
  classes: {
    eyebrow: 'The standard',
    h1: 'Bag difficulty classes',
    lead: 'The class depends on structure, number of pieces, interior and hardware. I assign it with the quote, after seeing the 3/4 views and the measurements. Prices per model, excluding VAT.',
    level: 'Difficulty {n} of 8',
    examples: 'Examples:',
    list: [
      ['Essential', 'Flat bag without gussets, simple lining, webbing handles. Up to about 10 pieces.', 'flat shopper, tote without base'],
      ['Simple', 'Base or gussets in a single band, one inside pocket, simple closure. Up to about 20 pieces.', 'tote with base, simple bucket bag'],
      ['Intermediate', 'Separate bands and gussets, flap, zip, 2-3 inside pockets, shoulder strap and standard hardware. About 20-35 pieces.', 'flap crossbody, shoulder bag'],
      ['Structured', 'Reinforcements and padding, binding or piping, more compartments, decorative work such as lacing. About 35-50 pieces.', 'structured handbag, satchel'],
      ['Complex', 'Bellows gussets, dividers, several zips and outside pockets, custom hardware, piping. About 50-70 pieces.', 'bowling bag, accordion bag'],
      ['Advanced', 'Many applied components: straps and buckles, quilting, crafted outside pockets, feet, detachable straps. About 70-90 pieces.', 'saddle bag with straps, quilted dome bag'],
      ['Superior', 'Rigid or semi-rigid structures, metal closures and frames built into the pattern, bases with feet, high-end finishing. About 90-110 pieces.', 'rigid handbag, structured top handle'],
      ['High complexity', '3D shapes and complex developments, joins between different forms, new construction studied from scratch and shape trials. Over 110 pieces.', 'rigid box bag, minaudière, sculptural shapes']
    ],
    extrasH: 'Other services and changes',
    extras: [
      ['Small leather goods', 'from 200 €', 'wallets, card holders, pouches'],
      ['Consumption and BOM', '+100 €', 'per model, optional'],
      ['Small additions', '+30%', 'pockets, appliqués'],
      ['Structural variants', '+50-70%', 'new construction or new development']
    ],
    designH: 'Do you also need design?',
    designP: 'Classes A to H cover pattern making only, on an already defined design. If the model must also be designed or developed from an idea, design is billed hourly or agreed for the whole collection.',
    designCta: 'Let’s talk about the collection',
    designSubject: 'Collection design and pattern making'
  },
  sheet: {
    eyebrow: 'To get started',
    h1: 'The tech pack I need',
    lead: 'With a photo of the front only, I can give just an estimate. For an exact price and pattern I need the technical drawing with views and measurements, like the examples on this page.',
    diagram: { front: 'FRONT', side: 'SIDE', w: 'W – width', h: 'H – height', d: 'D – depth', drop: 'handle drop', aria: 'Technical drawing scheme: front view with width, height and handle drop, side view with depth' },
    caption: 'Measurements in cm or mm. A hand-drawn or vector technical drawing is perfectly fine.',
    items: [
      ['Views', 'Front, back, side, top and bottom, plus a 3/4 view.'],
      ['Overall dimensions', 'Width, height and depth, at the top and at the base if the bag widens or narrows.'],
      ['Style measurements', 'Flap and overlap, position of closures, distance between attachments, width of bands, loops and appliqués.'],
      ['Handles and straps', 'Drop, width and length; whether they are adjustable or detachable.'],
      ['Interior', 'Lining, pockets with their measurements, zips and dividers.'],
      ['Materials and hardware', 'Material and colour of each piece; code, size and finish of rings, buckles, closures and feet, or their data sheets.'],
      ['Workmanship', 'Painted or turned edges, piping, topstitching, quilting, lacing, logo and tolerances.']
    ],
    examplesH: 'Tech pack examples',
    examplesLead: 'This is the kind of tech pack I work with. For each one I show the class I would assign to that model.',
    classTag: 'Class {c}',
    enlarge: 'Open full screen',
    ex: [
      'Flap crossbody with inner divider, push-lock closure, decorative leather lace and zipped inside pocket.',
      'Flap crossbody with laced edges, tassel and buckle: decorative work along the whole outline.',
      'Structured handbag with metal clasp, feet, inner compartment and Alcantara lining.',
      'Bowling bag with top zip, zipped side pockets, adjustable and detachable strap.',
      'Two-material bowling bag with piping, twin zips, square rings and chain.',
      'Saddle bag with straps and buckles, zipped front pocket, feet and back pocket.',
      'Quilted dome bag with many metal appliqués, piping at the base and detachable strap.'
    ]
  },
  process: {
    eyebrow: 'Method',
    h1: 'How I work',
    steps: [
      ['You send me the material', 'Tech pack with views and measurements, the interior you want and hardware data sheets, if you already have them.'],
      ['Class and quote', 'I assign a class from A to H to each model and send you the quote with the delivery date.'],
      ['Start with 50%', 'Work starts with the first payment. Delivery in one week: the Monday after receiving the complete material.'],
      ['Review and balance', 'You review the work, then pay the remaining 50%.']
    ],
    info: [
      ['Payment and invoicing', 'Two online payments per item through Lemon Squeezy, a platform with international invoicing: suitable for companies based abroad too. You receive an invoice for each payment.'],
      ['Reading and printing files', 'No software to buy. DWG/DXF and PDF files open in any CAD viewer and print at 1:1 scale. I guide you through the first opening and printing.'],
      ['Changes and variants', 'Agreed beforehand. Small additions +30% of the model price; variants with new construction or new development +50-70%.'],
      ['Design', 'If design is needed besides pattern making, it is billed hourly or agreed for the whole collection.']
    ]
  },
  software: {
    eyebrow: 'For in-house pattern making',
    h1: 'Leonardo Pattern Design',
    p1: 'The leather goods pattern making software I developed. It installs on ZWCAD (2024-2027) and AutoCAD (2018 and 2024-2027) and adds over 350 commands.',
    features: [
      ['Shapes and developments', 'Panels, bands, gussets, bases, bellows, linings; flattening of 3D surfaces.'],
      ['Notches and outlines', 'Notches in several shapes and checks for open or double outlines.'],
      ['Nesting', 'Layout of pieces on the hide, with strategies to compare.'],
      ['Consumption and BOM', 'Consumption and cost calculation, export to Excel, CSV and HTML.'],
      ['Cutting', 'Files for ATOM, AAMA and Gerber machines and plotters.'],
      ['AI pattern maker', 'An assistant built into the CAD that reads the drawing and asks for confirmation before changing it.']
    ],
    price: 'Monthly licence with no commitment, 199.99 € + VAT. Free trial.',
    cta: 'Discover Leonardo on guasqui.it',
    boxH: 'Service and software are independent',
    boxP: 'You don’t need Leonardo to receive my patterns. The software is for those who want to develop patterns in-house.'
  },
  contact: {
    eyebrow: 'Contact',
    h1: 'Send me your first model: I’ll reply with class, price and delivery date.',
    lead: 'Write to me and attach the tech pack with views and measurements.',
    portfolio: 'Portfolio and references',
    checkH: 'What to attach to your request'
  }
};
