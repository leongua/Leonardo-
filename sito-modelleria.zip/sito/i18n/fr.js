module.exports = {
  lang: 'fr', dir: 'ltr', label: 'FR', name: 'Français',
  nav: { home: 'Accueil', classes: 'Classes et prix', sheet: 'Fiche technique', process: 'Ma méthode', software: 'Logiciel', contact: 'Contact' },
  menu: 'Menu',
  brandSub: 'Modélisme',
  titles: { home: 'Modélisme pour sacs et petite maroquinerie', classes: 'Classes de difficulté et prix', sheet: 'La fiche technique dont j’ai besoin', process: 'Ma méthode', software: 'Leonardo Pattern Design', contact: 'Contact' },
  metaDesc: 'Modéliste indépendant pour sacs et petite maroquinerie : patronages prêts à la coupe, classes de difficulté de A à H, livraison en une semaine.',
  ctaQuote: 'Demander un devis',
  mailSubject: 'Demande de devis modélisme',
  footerLoc: 'Leonardo Guasqui · Montespertoli, Toscane',
  footerNote: 'Prix hors TVA · © 2026',
  home: {
    eyebrow: 'Modéliste indépendant · Sacs et petite maroquinerie',
    h1: 'Des patronages prêts à la coupe, avec un prix clair avant de commencer.',
    lead: 'Depuis 2017, je travaille sur les prototypes et l’industrialisation dans une manufacture toscane de maroquinerie de luxe. Chaque sac est classé de A à H selon sa complexité : vous savez tout de suite combien il coûte et quand il arrive.',
    seeClasses: 'Voir les classes',
    stats: [['1 semaine', 'livraison le lundi suivant'], ['8 classes', 'de A à H, prix fixe par classe'], ['DWG · DXF · PDF', 'aucun logiciel à acheter']],
    deliverH: 'Ce que je livre',
    deliver: [
      ['Patronages complets', 'Tous les composants : cuir, doublure, renforts et intérieur, avec valeurs de couture et crans, prêts à la coupe.'],
      ['Consommations et nomenclature', 'Sur demande, le calcul des consommations et la nomenclature (BOM) du modèle, pour planifier matières et coûts.'],
      ['Fichiers prêts à l’emploi', 'DWG/DXF et PDF, lisibles avec n’importe quelle visionneuse CAO, même gratuite. Impression à l’échelle 1:1 sur imprimante ou traceur.']
    ],
    nextH: 'Par où commencer',
    next: [
      ['Trouvez la classe de votre modèle', 'Huit niveaux de complexité, chacun avec son prix.'],
      ['Préparez la fiche technique', 'Les vues et les mesures dont j’ai besoin, avec de vrais exemples.'],
      ['Découvrez ma méthode', 'Délais, paiement en deux fois et fichiers livrés.']
    ],
    open: 'Ouvrir'
  },
  classes: {
    eyebrow: 'Le standard',
    h1: 'Classes de difficulté des sacs',
    lead: 'La classe dépend de la structure, du nombre de pièces, de l’intérieur et des accessoires métalliques. Je l’attribue avec le devis, après avoir vu les vues de 3/4 et les mesures. Prix par modèle, hors TVA.',
    level: 'Difficulté {n} sur 8',
    examples: 'Exemples :',
    list: [
      ['Essentiel', 'Sac plat sans soufflets, doublure simple, anses en sangle. Jusqu’à environ 10 pièces.', 'cabas plat, tote sans fond'],
      ['Simple', 'Fond ou côtés en bande unique, une poche intérieure, fermeture simple. Jusqu’à environ 20 pièces.', 'tote avec fond, seau simple'],
      ['Intermédiaire', 'Bandes et côtés séparés, rabat, zip, 2-3 poches intérieures, bandoulière et accessoires standards. Environ 20-35 pièces.', 'sac à rabat, crossbody'],
      ['Structuré', 'Renforts et rembourrages, bordures ou passepoils, plus de compartiments, travaux décoratifs comme le laçage. Environ 35-50 pièces.', 'sac à main structuré, cartable'],
      ['Complexe', 'Soufflets, séparateurs, plusieurs zips et poches extérieures, accessoires sur mesure, passepoils. Environ 50-70 pièces.', 'sac bowling, sac à soufflet'],
      ['Avancé', 'Nombreux composants appliqués : sangles et boucles, matelassage, poches extérieures travaillées, pieds, bandoulières amovibles. Environ 70-90 pièces.', 'saddle bag à sangles, sac bombé matelassé'],
      ['Supérieur', 'Structures rigides ou semi-rigides, fermetures et armatures métalliques intégrées au patronage, fonds avec pieds, finitions haut de gamme. Environ 90-110 pièces.', 'sac à main rigide, top handle structuré'],
      ['Haute complexité', 'Formes 3D et développements complexes, raccords entre formes différentes, construction nouvelle étudiée de zéro et essais de forme. Plus de 110 pièces.', 'malle rigide, minaudière, formes sculpturales']
    ],
    extrasH: 'Autres services et modifications',
    extras: [
      ['Petite maroquinerie', 'à partir de 200 €', 'portefeuilles, porte-cartes, trousses'],
      ['Consommations et BOM', '+100 €', 'par modèle, en option'],
      ['Petits ajouts', '+30 %', 'poches, applications'],
      ['Variantes structurelles', '+50-70 %', 'nouvelle construction ou nouveau développement']
    ],
    designH: 'Besoin aussi du design ?',
    designP: 'Les classes de A à H concernent uniquement le modélisme sur un design déjà défini. Si le modèle doit aussi être dessiné ou développé à partir d’une idée, le design est facturé à l’heure ou convenu pour toute la collection.',
    designCta: 'Parlons de la collection',
    designSubject: 'Design et modélisme collection'
  },
  sheet: {
    eyebrow: 'Pour travailler',
    h1: 'La fiche technique dont j’ai besoin',
    lead: 'Avec une photo de face uniquement, je ne peux donner qu’une estimation. Pour un prix et un patronage précis, il me faut le dessin technique avec les vues et les mesures, comme dans les exemples de cette page.',
    diagram: { front: 'FACE', side: 'CÔTÉ', w: 'L – largeur', h: 'H – hauteur', d: 'P – profondeur', drop: 'hauteur d’anse', aria: 'Schéma de dessin technique : vue de face avec largeur, hauteur et hauteur d’anse, vue de côté avec profondeur' },
    caption: 'Mesures en cm ou mm. Un dessin technique à la main ou vectoriel convient parfaitement.',
    items: [
      ['Vues', 'Face, dos, côté, dessus et dessous, plus une vue de 3/4.'],
      ['Dimensions hors tout', 'Largeur, hauteur et profondeur, en haut et à la base si le sac s’évase ou se resserre.'],
      ['Mesures de style', 'Rabat et recouvrement, position des fermetures, distance entre les attaches, largeur des bandes, passants et applications.'],
      ['Anses et bandoulières', 'Hauteur, largeur et longueur ; réglables ou amovibles.'],
      ['Intérieur', 'Doublure, poches avec leurs mesures, zips et séparateurs.'],
      ['Matières et accessoires', 'Matière et couleur de chaque pièce ; code, taille et finition des anneaux, boucles, fermetures et pieds, ou leurs fiches techniques.'],
      ['Façonnage', 'Tranches peintes ou rempliées, passepoils, surpiqûres, matelassage, laçage, logo et tolérances.']
    ],
    examplesH: 'Exemples de fiches techniques',
    examplesLead: 'Voici le type de fiches avec lesquelles je travaille. Pour chacune, j’indique la classe que j’attribuerais à ce modèle.',
    classTag: 'Classe {c}',
    enlarge: 'Ouvrir en plein écran',
    ex: [
      'Sac à rabat avec cloison intérieure, fermeture à pression, lacet décoratif et poche intérieure zippée.',
      'Sac à rabat lacé sur les bords, pompon et boucle : travail décoratif sur tout le contour.',
      'Sac à main structuré avec fermoir métallique, pieds, compartiment intérieur et doublure en Alcantara.',
      'Sac bowling avec zip supérieur, poches latérales zippées, bandoulière réglable et amovible.',
      'Sac bowling bi-matière avec passepoil, double zip, anneaux carrés et chaîne.',
      'Saddle bag avec sangles et boucles, poche avant zippée, pieds et poche arrière.',
      'Sac bombé matelassé avec nombreuses applications métalliques, passepoil au fond et bandoulière amovible.'
    ]
  },
  process: {
    eyebrow: 'Méthode',
    h1: 'Ma méthode',
    steps: [
      ['Vous m’envoyez le matériel', 'Fiche technique avec vues et mesures, intérieur souhaité et fiches des accessoires métalliques, si vous les avez déjà.'],
      ['Classe et devis', 'J’attribue une classe de A à H à chaque modèle et je vous envoie le devis avec la date de livraison.'],
      ['Lancement avec 50 %', 'Le travail démarre avec le premier paiement. Livraison en une semaine : le lundi suivant la réception du matériel complet.'],
      ['Validation et solde', 'Vous examinez le travail, puis vous réglez les 50 % restants.']
    ],
    info: [
      ['Paiement et facturation', 'Deux paiements en ligne par article via Lemon Squeezy, plateforme avec facturation internationale : adaptée aussi aux entreprises basées à l’étranger. Chaque paiement donne lieu à une facture.'],
      ['Lecture et impression des fichiers', 'Aucun logiciel à acheter. Les fichiers DWG/DXF et PDF s’ouvrent avec n’importe quelle visionneuse CAO et s’impriment à l’échelle 1:1. Je vous guide pour la première ouverture et impression.'],
      ['Modifications et variantes', 'Convenues à l’avance. Petits ajouts +30 % du prix du modèle ; variantes avec nouvelle construction ou nouveau développement +50-70 %.'],
      ['Design', 'Si le design est nécessaire en plus du modélisme, il est facturé à l’heure ou convenu pour toute la collection.']
    ]
  },
  software: {
    eyebrow: 'Pour le modélisme en interne',
    h1: 'Leonardo Pattern Design',
    p1: 'Le logiciel de modélisme pour la maroquinerie que j’ai développé. Il s’installe sur ZWCAD (2024-2027) et AutoCAD (2018 et 2024-2027) et ajoute plus de 350 commandes.',
    features: [
      ['Formes et développements', 'Panneaux, bandes, côtés, fonds, soufflets, doublures ; mise à plat de surfaces 3D.'],
      ['Crans et contours', 'Crans de plusieurs formes et contrôle des contours ouverts ou doublés.'],
      ['Placement', 'Placement des pièces sur la peau, avec des stratégies à comparer.'],
      ['Consommations et BOM', 'Calcul des consommations et des coûts, export Excel, CSV et HTML.'],
      ['Coupe', 'Fichiers pour machines et traceurs ATOM, AAMA et Gerber.'],
      ['Modéliste IA', 'Un assistant intégré à la CAO qui lit le dessin et demande confirmation avant de le modifier.']
    ],
    price: 'Licence mensuelle sans engagement, 199,99 € HT. Essai gratuit.',
    cta: 'Découvrir Leonardo sur guasqui.it',
    boxH: 'Service et logiciel sont indépendants',
    boxP: 'Vous n’avez pas besoin de Leonardo pour recevoir mes patronages. Le logiciel s’adresse à ceux qui veulent développer les modèles en interne.'
  },
  contact: {
    eyebrow: 'Contact',
    h1: 'Envoyez-moi votre premier modèle : je réponds avec la classe, le prix et la date de livraison.',
    lead: 'Écrivez-moi en joignant la fiche technique avec vues et mesures.',
    portfolio: 'Portfolio et références',
    checkH: 'À joindre à votre demande'
  }
};
