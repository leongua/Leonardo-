module.exports = {
  lang: 'it', dir: 'ltr', label: 'IT', name: 'Italiano',
  nav: { home: 'Home', classes: 'Classi e prezzi', sheet: 'Scheda tecnica', process: 'Come lavoro', software: 'Software', contact: 'Contatti' },
  menu: 'Menu',
  brandSub: 'Modelleria',
  titles: { home: 'Modelleria per borse e piccola pelletteria', classes: 'Classi di difficoltà e prezzi', sheet: 'La scheda tecnica che mi serve', process: 'Come lavoro', software: 'Leonardo Pattern Design', contact: 'Contatti' },
  metaDesc: 'Modellista freelance per borse e piccola pelletteria: cartamodelli pronti per il taglio, classi di difficoltà da A a H, consegna in una settimana.',
  ctaQuote: 'Richiedi un preventivo',
  mailSubject: 'Richiesta preventivo modelleria',
  footerLoc: 'Leonardo Guasqui · Montespertoli, Toscana',
  footerNote: 'Prezzi IVA esclusa · © 2026',
  home: {
    eyebrow: 'Modellista freelance · Borse e piccola pelletteria',
    h1: 'Cartamodelli pronti per il taglio, con un prezzo chiaro prima di iniziare.',
    lead: "Dal 2017 lavoro nel campionario e nell'industrializzazione di una manifattura toscana di pelletteria di lusso. Ogni borsa viene classificata da A a H in base alla complessità: sapete subito quanto costa e quando arriva.",
    seeClasses: 'Vedi le classi',
    stats: [['1 settimana', 'consegna il lunedì successivo'], ['8 classi', 'da A a H, prezzo fisso per classe'], ['DWG · DXF · PDF', 'nessun software da acquistare']],
    deliverH: 'Cosa consegno',
    deliver: [
      ['Cartamodelli completi', 'Tutti i componenti: pelle, fodera, rinforzi e interni, con margini di cucitura e tacche, pronti per il taglio.'],
      ['Consumi e distinta base', 'Su richiesta, il calcolo dei consumi e la DIBA del modello, per pianificare materiali e costi.'],
      ['File pronti da usare', 'DWG/DXF e PDF, apribili con qualsiasi lettore CAD anche gratuito. Si stampano in scala 1:1 con una stampante o un plotter.']
    ],
    nextH: 'Da dove iniziare',
    next: [
      ['Scoprite la classe del vostro modello', 'Otto livelli di complessità, ciascuno con il suo prezzo.'],
      ['Preparate la scheda tecnica', 'Le viste e le misure che mi servono, con esempi reali.'],
      ['Leggete come lavoro', 'Tempi, pagamento in due tranche e file consegnati.']
    ],
    open: 'Apri'
  },
  classes: {
    eyebrow: 'Lo standard',
    h1: 'Classi di difficoltà delle borse',
    lead: 'La classe dipende da struttura, numero di pezzi, interni e metalli. La assegno con il preventivo, dopo aver visto le viste a 3/4 e le misure. Prezzi per modello, IVA esclusa.',
    level: 'Difficoltà {n} su 8',
    examples: 'Esempi:',
    list: [
      ['Essenziale', 'Borsa piatta senza fianchi, fodera semplice, manici a fettuccia. Fino a circa 10 pezzi.', 'shopper piatta, tote senza fondo'],
      ['Semplice', 'Fondo o fianchi a fascia unica, una tasca interna, chiusura semplice. Fino a circa 20 pezzi.', 'tote con fondo, secchiello semplice'],
      ['Intermedia', 'Fasce e fianchi separati, pattina, zip, 2-3 tasche interne, tracolla e metalli standard. Circa 20-35 pezzi.', 'tracolla con pattina, crossbody'],
      ['Strutturata', 'Rinforzi e imbottiture, bordature o cannoni, più scomparti, lavorazioni decorative come gli intrecci. Circa 35-50 pezzi.', 'borsa a mano strutturata, satchel'],
      ['Complessa', 'Soffietti, divisori, più zip e tasche esterne, metalli su misura, filetti. Circa 50-70 pezzi.', 'bowling, borsa a soffietto'],
      ['Avanzata', 'Molti componenti applicati: cinghie e fibbie, trapuntature, tasche esterne lavorate, piedini, tracolle staccabili. Circa 70-90 pezzi.', 'saddle bag con cinghie, bauletto trapuntato'],
      ['Superiore', 'Strutture rigide o semirigide, chiusure e telai metallici integrati nel modello, fondi con piedini, finiture di alta gamma. Circa 90-110 pezzi.', 'borsa a mano rigida, top handle strutturata'],
      ['Alta complessità', 'Forme 3D e sviluppi complessi, raccordi tra figure diverse, costruzione nuova da studiare da zero e prove di forma. Oltre 110 pezzi.', 'bauletto rigido, minaudière, forme scultoree']
    ],
    extrasH: 'Altri servizi e modifiche',
    extras: [
      ['Piccola pelletteria', 'da 200 €', 'portafogli, portacarte, astucci'],
      ['Consumi e DIBA', '+100 €', 'a modello, opzionale'],
      ['Piccole aggiunte', '+30%', 'tasche, applicazioni'],
      ['Varianti strutturali', '+50-70%', 'nuova costruzione o nuovo sviluppo']
    ],
    designH: 'Serve anche il design?',
    designP: "Le classi da A a H riguardano la sola modelleria su un design già definito. Se il modello va anche disegnato o sviluppato da un'idea, il design si fattura a ore oppure si concorda per l'intera collezione.",
    designCta: 'Parliamo della collezione',
    designSubject: 'Design e modelleria collezione'
  },
  sheet: {
    eyebrow: 'Per lavorare',
    h1: 'La scheda tecnica che mi serve',
    lead: "Con una foto del solo fronte posso dare solo una stima. Per un prezzo e un modello precisi mi servono il disegno tecnico con le viste e le misure, come negli esempi di questa pagina.",
    diagram: { front: 'FRONTE', side: 'FIANCO', w: 'L – larghezza', h: 'H – altezza', d: 'P – profondità', drop: 'drop manico', aria: 'Schema di disegno tecnico: vista frontale con larghezza, altezza e drop del manico, vista laterale con profondità' },
    caption: 'Misure in cm o mm. Un disegno tecnico a mano o in vettoriale va benissimo.',
    items: [
      ['Viste', 'Fronte, retro, fianco, sopra e fondo, più una vista a 3/4.'],
      ["Misure d'ingombro", 'Larghezza, altezza e profondità, in alto e alla base se la borsa si allarga o si stringe.'],
      ['Misure di stile', 'Pattina e sormonto, posizione delle chiusure, distanza tra gli attacchi, larghezza di fasce, passanti e applicazioni.'],
      ['Manici e tracolle', 'Drop, larghezza e lunghezza; se sono regolabili o staccabili.'],
      ['Interni', 'Fodera, tasche con le loro misure, zip e divisori.'],
      ['Materiali e metalli', 'Materiale e colore di ogni pezzo; codice, misura e finitura di anelli, fibbie, chiusure e piedini, o le loro schede tecniche.'],
      ['Lavorazioni', 'Bordi dipinti o rivoltati, filetti, impunture, trapuntature, intrecci, logo e tolleranze.']
    ],
    examplesH: 'Esempi di schede tecniche',
    examplesLead: 'Ecco il tipo di schede con cui lavoro. Per ognuna indico la classe che assegnerei a quel modello.',
    classTag: 'Classe {c}',
    enlarge: 'Apri a schermo intero',
    ex: [
      'Tracolla con pattina e tramezza interna, chiusura a pressione, laccio decorativo e tasca interna con zip.',
      'Tracolla con pattina intrecciata a laccio, nappina e fibbia: lavorazione decorativa su tutto il contorno.',
      'Borsa a mano strutturata con chiusura metallica, piedini, scomparto interno e fodera in Alcantara.',
      'Bowling con zip superiore, tasche laterali con zip, tracolla regolabile e staccabile.',
      'Bowling in due materiali con filetto, doppia zip, anelli quadri e catena.',
      'Saddle bag con cinghie e fibbie, tasca frontale con zip, piedini e tasca posteriore.',
      'Bauletto trapuntato con molte applicazioni metalliche, filetto al fondo e tracolla staccabile.'
    ]
  },
  process: {
    eyebrow: 'Metodo',
    h1: 'Come lavoro',
    steps: [
      ['Mi inviate il materiale', 'Scheda tecnica con viste e misure, interni desiderati e schede dei metalli, se li avete già.'],
      ['Classe e preventivo', 'Assegno la classe da A a H a ogni modello e vi mando il preventivo con la data di consegna.'],
      ['Avvio con il 50%', 'Il lavoro parte con il primo pagamento. Consegna in una settimana: il lunedì successivo alla ricezione del materiale completo.'],
      ['Verifica e saldo', 'Visionate il lavoro, poi saldate il restante 50%.']
    ],
    info: [
      ['Pagamento e fatturazione', "Due pagamenti online per articolo tramite Lemon Squeezy, piattaforma con fatturazione internazionale: adatta anche ad aziende con sede all'estero. Per ogni pagamento ricevete la fattura."],
      ['Lettura e stampa dei file', 'Non serve acquistare nessun software. I file DWG/DXF e PDF si aprono con qualsiasi lettore CAD e si stampano in scala 1:1. Vi guido nella prima apertura e stampa.'],
      ['Modifiche e varianti', 'Si concordano prima. Piccole aggiunte +30% del prezzo del modello; varianti con nuova costruzione o nuovo sviluppo +50-70%.'],
      ['Design', "Se oltre alla modelleria serve il design, si fattura a ore oppure si concorda per l'intera collezione."]
    ]
  },
  software: {
    eyebrow: 'Per fare modelleria in azienda',
    h1: 'Leonardo Pattern Design',
    p1: 'Il software di modelleria per pelletteria che ho sviluppato. Si installa su ZWCAD (2024-2027) e AutoCAD (2018 e 2024-2027) e aggiunge oltre 350 comandi.',
    features: [
      ['Sagome e sviluppi', 'Quadranti, fasce, fianchi, fondi, soffietti, fodere; sviluppo in piano di superfici 3D.'],
      ['Tacche e contorni', 'Tacche in varie forme e controllo dei contorni aperti o doppi.'],
      ['Nesting', 'Disposizione dei pezzi sulla pelle, con strategie da confrontare.'],
      ['Consumi e DIBA', 'Calcolo di consumi e costi, esportazione in Excel, CSV e HTML.'],
      ['Taglio', 'File per macchine e plotter ATOM, AAMA e Gerber.'],
      ['Modellista IA', 'Un assistente integrato nel CAD che legge il disegno e chiede conferma prima di modificarlo.']
    ],
    price: 'Licenza mensile senza vincolo, 199,99 € + IVA. Prova gratuita.',
    cta: 'Scopri Leonardo su guasqui.it',
    boxH: 'Servizio e software sono indipendenti',
    boxP: 'Per ricevere i miei modelli non vi serve Leonardo. Il software è per chi vuole sviluppare i modelli internamente.'
  },
  contact: {
    eyebrow: 'Contatti',
    h1: 'Mandatemi il primo modello: vi rispondo con classe, prezzo e data di consegna.',
    lead: 'Scrivetemi allegando la scheda tecnica con viste e misure.',
    portfolio: 'Portfolio e referenze',
    checkH: 'Da allegare alla richiesta'
  }
};
