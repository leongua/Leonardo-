module.exports = {
  lang: 'es', dir: 'ltr', label: 'ES', name: 'Español',
  nav: { home: 'Inicio', classes: 'Clases y precios', sheet: 'Ficha técnica', process: 'Cómo trabajo', software: 'Software', contact: 'Contacto' },
  menu: 'Menú',
  brandSub: 'Patronaje',
  titles: { home: 'Patronaje para bolsos y pequeña marroquinería', classes: 'Clases de dificultad y precios', sheet: 'La ficha técnica que necesito', process: 'Cómo trabajo', software: 'Leonardo Pattern Design', contact: 'Contacto' },
  metaDesc: 'Patronista freelance para bolsos y pequeña marroquinería: patrones listos para el corte, clases de dificultad de la A a la H, entrega en una semana.',
  ctaQuote: 'Solicitar presupuesto',
  mailSubject: 'Solicitud de presupuesto de patronaje',
  footerLoc: 'Leonardo Guasqui · Montespertoli, Toscana',
  footerNote: 'Precios sin IVA · © 2026',
  home: {
    eyebrow: 'Patronista freelance · Bolsos y pequeña marroquinería',
    h1: 'Patrones listos para el corte, con un precio claro antes de empezar.',
    lead: 'Desde 2017 trabajo en muestrario e industrialización en una manufactura toscana de marroquinería de lujo. Cada bolso se clasifica de la A a la H según su complejidad: sabe enseguida cuánto cuesta y cuándo llega.',
    seeClasses: 'Ver las clases',
    stats: [['1 semana', 'entrega el lunes siguiente'], ['8 clases', 'de la A a la H, precio fijo por clase'], ['DWG · DXF · PDF', 'sin software que comprar']],
    deliverH: 'Qué entrego',
    deliver: [
      ['Patrones completos', 'Todos los componentes: piel, forro, refuerzos e interior, con márgenes de costura y piquetes, listos para el corte.'],
      ['Consumos y escandallo', 'Bajo pedido, el cálculo de consumos y la lista de materiales (BOM) del modelo, para planificar materiales y costes.'],
      ['Archivos listos para usar', 'DWG/DXF y PDF, que se abren con cualquier visor CAD, también gratuito. Se imprimen a escala 1:1 con impresora o plóter.']
    ],
    nextH: 'Por dónde empezar',
    next: [
      ['Descubra la clase de su modelo', 'Ocho niveles de complejidad, cada uno con su precio.'],
      ['Prepare la ficha técnica', 'Las vistas y medidas que necesito, con ejemplos reales.'],
      ['Lea cómo trabajo', 'Plazos, pago en dos partes y archivos entregados.']
    ],
    open: 'Abrir'
  },
  classes: {
    eyebrow: 'El estándar',
    h1: 'Clases de dificultad de los bolsos',
    lead: 'La clase depende de la estructura, el número de piezas, el interior y los herrajes. La asigno con el presupuesto, tras ver las vistas de 3/4 y las medidas. Precios por modelo, sin IVA.',
    level: 'Dificultad {n} de 8',
    examples: 'Ejemplos:',
    list: [
      ['Esencial', 'Bolso plano sin fuelles, forro sencillo, asas de cinta. Hasta unas 10 piezas.', 'shopper plano, tote sin base'],
      ['Sencilla', 'Base o laterales de una sola banda, un bolsillo interior, cierre sencillo. Hasta unas 20 piezas.', 'tote con base, bolso saco sencillo'],
      ['Intermedia', 'Bandas y laterales separados, solapa, cremallera, 2-3 bolsillos interiores, bandolera y herrajes estándar. Unas 20-35 piezas.', 'bandolera con solapa, crossbody'],
      ['Estructurada', 'Refuerzos y acolchados, ribetes o vivos, más compartimentos, trabajos decorativos como el trenzado. Unas 35-50 piezas.', 'bolso de mano estructurado, satchel'],
      ['Compleja', 'Fuelles, separadores, varias cremalleras y bolsillos exteriores, herrajes a medida, vivos. Unas 50-70 piezas.', 'bolso bowling, bolso de fuelle'],
      ['Avanzada', 'Muchos componentes aplicados: correas y hebillas, acolchado, bolsillos exteriores trabajados, pies, bandoleras extraíbles. Unas 70-90 piezas.', 'saddle bag con correas, bolso baúl acolchado'],
      ['Superior', 'Estructuras rígidas o semirrígidas, cierres y armazones metálicos integrados en el patrón, bases con pies, acabados de alta gama. Unas 90-110 piezas.', 'bolso de mano rígido, top handle estructurado'],
      ['Alta complejidad', 'Formas 3D y desarrollos complejos, uniones entre figuras distintas, construcción nueva estudiada desde cero y pruebas de forma. Más de 110 piezas.', 'baúl rígido, minaudière, formas escultóricas']
    ],
    extrasH: 'Otros servicios y modificaciones',
    extras: [
      ['Pequeña marroquinería', 'desde 200 €', 'carteras, tarjeteros, estuches'],
      ['Consumos y BOM', '+100 €', 'por modelo, opcional'],
      ['Pequeños añadidos', '+30 %', 'bolsillos, aplicaciones'],
      ['Variantes estructurales', '+50-70 %', 'nueva construcción o nuevo desarrollo']
    ],
    designH: '¿Necesita también el diseño?',
    designP: 'Las clases de la A a la H cubren solo el patronaje sobre un diseño ya definido. Si el modelo también debe diseñarse o desarrollarse a partir de una idea, el diseño se factura por horas o se acuerda para toda la colección.',
    designCta: 'Hablemos de la colección',
    designSubject: 'Diseño y patronaje de colección'
  },
  sheet: {
    eyebrow: 'Para trabajar',
    h1: 'La ficha técnica que necesito',
    lead: 'Con una foto solo del frente únicamente puedo dar una estimación. Para un precio y un patrón precisos necesito el dibujo técnico con vistas y medidas, como en los ejemplos de esta página.',
    diagram: { front: 'FRENTE', side: 'LATERAL', w: 'A – ancho', h: 'H – alto', d: 'P – profundidad', drop: 'caída del asa', aria: 'Esquema de dibujo técnico: vista frontal con ancho, alto y caída del asa, vista lateral con profundidad' },
    caption: 'Medidas en cm o mm. Un dibujo técnico a mano o vectorial es perfectamente válido.',
    items: [
      ['Vistas', 'Frente, espalda, lateral, arriba y base, más una vista de 3/4.'],
      ['Medidas generales', 'Ancho, alto y profundidad, arriba y en la base si el bolso se ensancha o se estrecha.'],
      ['Medidas de estilo', 'Solapa y superposición, posición de los cierres, distancia entre los enganches, ancho de bandas, trabillas y aplicaciones.'],
      ['Asas y bandoleras', 'Caída, ancho y largo; si son regulables o extraíbles.'],
      ['Interior', 'Forro, bolsillos con sus medidas, cremalleras y separadores.'],
      ['Materiales y herrajes', 'Material y color de cada pieza; código, medida y acabado de anillas, hebillas, cierres y pies, o sus fichas técnicas.'],
      ['Acabados', 'Cantos pintados o doblados, vivos, pespuntes, acolchados, trenzados, logotipo y tolerancias.']
    ],
    examplesH: 'Ejemplos de fichas técnicas',
    examplesLead: 'Este es el tipo de fichas con las que trabajo. En cada una indico la clase que asignaría a ese modelo.',
    classTag: 'Clase {c}',
    enlarge: 'Abrir a pantalla completa',
    ex: [
      'Bandolera con solapa y separador interior, cierre a presión, cordón decorativo y bolsillo interior con cremallera.',
      'Bandolera con solapa trenzada con cordón, borla y hebilla: trabajo decorativo en todo el contorno.',
      'Bolso de mano estructurado con cierre metálico, pies, compartimento interior y forro de Alcantara.',
      'Bolso bowling con cremallera superior, bolsillos laterales con cremallera y bandolera regulable y extraíble.',
      'Bolso bowling en dos materiales con vivo, doble cremallera, anillas cuadradas y cadena.',
      'Saddle bag con correas y hebillas, bolsillo frontal con cremallera, pies y bolsillo trasero.',
      'Bolso baúl acolchado con muchas aplicaciones metálicas, vivo en la base y bandolera extraíble.'
    ]
  },
  process: {
    eyebrow: 'Método',
    h1: 'Cómo trabajo',
    steps: [
      ['Me envía el material', 'Ficha técnica con vistas y medidas, el interior deseado y las fichas de los herrajes, si ya los tiene.'],
      ['Clase y presupuesto', 'Asigno una clase de la A a la H a cada modelo y le envío el presupuesto con la fecha de entrega.'],
      ['Inicio con el 50 %', 'El trabajo comienza con el primer pago. Entrega en una semana: el lunes siguiente a la recepción del material completo.'],
      ['Revisión y saldo', 'Revisa el trabajo y después paga el 50 % restante.']
    ],
    info: [
      ['Pago y facturación', 'Dos pagos en línea por artículo a través de Lemon Squeezy, plataforma con facturación internacional: adecuada también para empresas con sede en el extranjero. Por cada pago recibe la factura.'],
      ['Lectura e impresión de archivos', 'No hace falta comprar ningún software. Los archivos DWG/DXF y PDF se abren con cualquier visor CAD y se imprimen a escala 1:1. Le guío en la primera apertura e impresión.'],
      ['Modificaciones y variantes', 'Se acuerdan antes. Pequeños añadidos +30 % del precio del modelo; variantes con nueva construcción o nuevo desarrollo +50-70 %.'],
      ['Diseño', 'Si además del patronaje se necesita el diseño, se factura por horas o se acuerda para toda la colección.']
    ]
  },
  software: {
    eyebrow: 'Para hacer patronaje en la empresa',
    h1: 'Leonardo Pattern Design',
    p1: 'El software de patronaje para marroquinería que he desarrollado. Se instala en ZWCAD (2024-2027) y AutoCAD (2018 y 2024-2027) y añade más de 350 comandos.',
    features: [
      ['Formas y desarrollos', 'Paneles, bandas, laterales, bases, fuelles, forros; desarrollo en plano de superficies 3D.'],
      ['Piquetes y contornos', 'Piquetes de varias formas y control de contornos abiertos o dobles.'],
      ['Nesting', 'Distribución de las piezas sobre la piel, con estrategias para comparar.'],
      ['Consumos y BOM', 'Cálculo de consumos y costes, exportación a Excel, CSV y HTML.'],
      ['Corte', 'Archivos para máquinas y plóteres ATOM, AAMA y Gerber.'],
      ['Patronista IA', 'Un asistente integrado en el CAD que lee el dibujo y pide confirmación antes de modificarlo.']
    ],
    price: 'Licencia mensual sin permanencia, 199,99 € + IVA. Prueba gratuita.',
    cta: 'Descubra Leonardo en guasqui.it',
    boxH: 'Servicio y software son independientes',
    boxP: 'Para recibir mis patrones no necesita Leonardo. El software es para quien quiere desarrollar los modelos internamente.'
  },
  contact: {
    eyebrow: 'Contacto',
    h1: 'Envíeme su primer modelo: le respondo con clase, precio y fecha de entrega.',
    lead: 'Escríbame adjuntando la ficha técnica con vistas y medidas.',
    portfolio: 'Portfolio y referencias',
    checkH: 'Qué adjuntar a la solicitud'
  }
};
