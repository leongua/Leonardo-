module.exports = {
  lang: 'de', dir: 'ltr', label: 'DE', name: 'Deutsch',
  nav: { home: 'Start', classes: 'Klassen & Preise', sheet: 'Technisches Datenblatt', process: 'Arbeitsweise', software: 'Software', contact: 'Kontakt' },
  menu: 'Menü',
  brandSub: 'Schnitttechnik',
  titles: { home: 'Schnitttechnik für Taschen und Kleinlederwaren', classes: 'Schwierigkeitsklassen und Preise', sheet: 'Das technische Datenblatt, das ich brauche', process: 'Arbeitsweise', software: 'Leonardo Pattern Design', contact: 'Kontakt' },
  metaDesc: 'Freiberuflicher Schnitttechniker für Taschen und Kleinlederwaren: zuschnittfertige Schnitte, Schwierigkeitsklassen von A bis H, Lieferung in einer Woche.',
  ctaQuote: 'Angebot anfordern',
  mailSubject: 'Angebotsanfrage Schnitttechnik',
  footerLoc: 'Leonardo Guasqui · Montespertoli, Toskana',
  footerNote: 'Preise zzgl. MwSt. · © 2026',
  home: {
    eyebrow: 'Freiberuflicher Schnitttechniker · Taschen und Kleinlederwaren',
    h1: 'Zuschnittfertige Schnitte, mit einem klaren Preis vor Arbeitsbeginn.',
    lead: 'Seit 2017 arbeite ich in Musterentwicklung und Industrialisierung bei einer toskanischen Manufaktur für Luxuslederwaren. Jede Tasche wird nach Komplexität von A bis H eingestuft: Sie wissen sofort, was sie kostet und wann sie kommt.',
    seeClasses: 'Klassen ansehen',
    stats: [['1 Woche', 'Lieferung am folgenden Montag'], ['8 Klassen', 'von A bis H, Festpreis pro Klasse'], ['DWG · DXF · PDF', 'keine Software erforderlich']],
    deliverH: 'Was ich liefere',
    deliver: [
      ['Vollständige Schnitte', 'Alle Teile: Leder, Futter, Verstärkungen und Innenausstattung, mit Nahtzugaben und Knipsen, zuschnittfertig.'],
      ['Verbrauch und Stückliste', 'Auf Wunsch die Verbrauchsberechnung und die Stückliste (BOM) des Modells, zur Planung von Material und Kosten.'],
      ['Sofort nutzbare Dateien', 'DWG/DXF und PDF, mit jedem CAD-Viewer zu öffnen, auch kostenlos. Druck im Maßstab 1:1 auf Drucker oder Plotter.']
    ],
    nextH: 'So starten Sie',
    next: [
      ['Finden Sie die Klasse Ihres Modells', 'Acht Komplexitätsstufen, jede mit eigenem Preis.'],
      ['Datenblatt vorbereiten', 'Die Ansichten und Maße, die ich brauche, mit echten Beispielen.'],
      ['Meine Arbeitsweise', 'Lieferzeit, Zahlung in zwei Raten und gelieferte Dateien.']
    ],
    open: 'Öffnen'
  },
  classes: {
    eyebrow: 'Der Standard',
    h1: 'Schwierigkeitsklassen für Taschen',
    lead: 'Die Klasse hängt von Konstruktion, Teileanzahl, Innenausstattung und Beschlägen ab. Ich lege sie mit dem Angebot fest, nachdem ich die 3/4-Ansichten und die Maße gesehen habe. Preise pro Modell, zzgl. MwSt.',
    level: 'Schwierigkeit {n} von 8',
    examples: 'Beispiele:',
    list: [
      ['Basis', 'Flache Tasche ohne Seitenteile, einfaches Futter, Gurtband-Henkel. Bis etwa 10 Teile.', 'flacher Shopper, Tote ohne Boden'],
      ['Einfach', 'Boden oder Seiten aus einem Streifen, eine Innentasche, einfacher Verschluss. Bis etwa 20 Teile.', 'Tote mit Boden, einfacher Beutel'],
      ['Mittel', 'Getrennte Streifen und Seitenteile, Überschlag, Reißverschluss, 2-3 Innentaschen, Schulterriemen und Standardbeschläge. Etwa 20-35 Teile.', 'Umhängetasche mit Überschlag, Crossbody'],
      ['Strukturiert', 'Verstärkungen und Polsterung, Einfassungen oder Paspeln, mehr Fächer, Ziertechniken wie Flechtungen. Etwa 35-50 Teile.', 'strukturierte Handtasche, Satchel'],
      ['Komplex', 'Faltenbälge, Trennwände, mehrere Reißverschlüsse und Außentaschen, Sonderbeschläge, Paspeln. Etwa 50-70 Teile.', 'Bowlingtasche, Akkordeontasche'],
      ['Fortgeschritten', 'Viele aufgesetzte Teile: Riemen und Schnallen, Steppung, gearbeitete Außentaschen, Füße, abnehmbare Riemen. Etwa 70-90 Teile.', 'Satteltasche mit Riemen, gesteppte Kuppeltasche'],
      ['Gehoben', 'Feste oder halbfeste Konstruktionen, Metallverschlüsse und -bügel im Schnitt integriert, Böden mit Füßen, hochwertige Verarbeitung. Etwa 90-110 Teile.', 'feste Handtasche, strukturierte Top-Handle'],
      ['Höchste Komplexität', '3D-Formen und komplexe Abwicklungen, Übergänge zwischen verschiedenen Formen, neue Konstruktion von Grund auf und Formproben. Über 110 Teile.', 'feste Koffertasche, Minaudière, skulpturale Formen']
    ],
    extrasH: 'Weitere Leistungen und Änderungen',
    extras: [
      ['Kleinlederwaren', 'ab 200 €', 'Geldbörsen, Kartenetuis, Etuis'],
      ['Verbrauch und BOM', '+100 €', 'pro Modell, optional'],
      ['Kleine Ergänzungen', '+30 %', 'Taschen, Applikationen'],
      ['Strukturelle Varianten', '+50-70 %', 'neue Konstruktion oder neue Entwicklung']
    ],
    designH: 'Brauchen Sie auch Design?',
    designP: 'Die Klassen A bis H gelten nur für die Schnitttechnik nach einem bereits festgelegten Design. Muss das Modell auch entworfen oder aus einer Idee entwickelt werden, wird das Design nach Stunden abgerechnet oder für die ganze Kollektion vereinbart.',
    designCta: 'Über die Kollektion sprechen',
    designSubject: 'Design und Schnitttechnik Kollektion'
  },
  sheet: {
    eyebrow: 'Für die Arbeit',
    h1: 'Das technische Datenblatt, das ich brauche',
    lead: 'Mit einem Foto nur von vorne kann ich lediglich schätzen. Für einen genauen Preis und Schnitt brauche ich die technische Zeichnung mit Ansichten und Maßen, wie in den Beispielen auf dieser Seite.',
    diagram: { front: 'VORNE', side: 'SEITE', w: 'B – Breite', h: 'H – Höhe', d: 'T – Tiefe', drop: 'Henkelhöhe', aria: 'Schema einer technischen Zeichnung: Vorderansicht mit Breite, Höhe und Henkelhöhe, Seitenansicht mit Tiefe' },
    caption: 'Maße in cm oder mm. Eine technische Zeichnung von Hand oder als Vektor ist völlig ausreichend.',
    items: [
      ['Ansichten', 'Vorne, hinten, Seite, oben und Boden, dazu eine 3/4-Ansicht.'],
      ['Außenmaße', 'Breite, Höhe und Tiefe, oben und am Boden, falls die Tasche sich weitet oder verjüngt.'],
      ['Stilmaße', 'Überschlag und Überlappung, Position der Verschlüsse, Abstand der Befestigungen, Breite von Streifen, Schlaufen und Applikationen.'],
      ['Henkel und Riemen', 'Höhe, Breite und Länge; verstellbar oder abnehmbar.'],
      ['Innenausstattung', 'Futter, Taschen mit Maßen, Reißverschlüsse und Trennwände.'],
      ['Material und Beschläge', 'Material und Farbe jedes Teils; Code, Größe und Oberfläche von Ringen, Schnallen, Verschlüssen und Füßen, oder deren Datenblätter.'],
      ['Verarbeitung', 'Gefärbte oder umgebuggte Kanten, Paspeln, Ziernähte, Steppungen, Flechtungen, Logo und Toleranzen.']
    ],
    examplesH: 'Beispiele technischer Datenblätter',
    examplesLead: 'So sehen die Datenblätter aus, mit denen ich arbeite. Zu jedem gebe ich die Klasse an, die ich dem Modell zuordnen würde.',
    classTag: 'Klasse {c}',
    enlarge: 'Im Vollbild öffnen',
    ex: [
      'Umhängetasche mit Überschlag, Innentrennwand, Druckverschluss, Zierschnur und Innentasche mit Reißverschluss.',
      'Umhängetasche mit geflochtenem Überschlagrand, Quaste und Schnalle: Zierarbeit am ganzen Umriss.',
      'Strukturierte Handtasche mit Metallverschluss, Füßen, Innenfach und Alcantara-Futter.',
      'Bowlingtasche mit oberem Reißverschluss, seitlichen Reißverschlusstaschen, verstellbarem und abnehmbarem Riemen.',
      'Bowlingtasche aus zwei Materialien mit Paspel, Doppelreißverschluss, Vierkantringen und Kette.',
      'Satteltasche mit Riemen und Schnallen, vorderer Reißverschlusstasche, Füßen und Rückentasche.',
      'Gesteppte Kuppeltasche mit vielen Metallapplikationen, Paspel am Boden und abnehmbarem Riemen.'
    ]
  },
  process: {
    eyebrow: 'Methode',
    h1: 'Arbeitsweise',
    steps: [
      ['Sie senden mir die Unterlagen', 'Datenblatt mit Ansichten und Maßen, gewünschte Innenausstattung und Datenblätter der Beschläge, falls vorhanden.'],
      ['Klasse und Angebot', 'Ich ordne jedem Modell eine Klasse von A bis H zu und sende Ihnen das Angebot mit Liefertermin.'],
      ['Start mit 50 %', 'Die Arbeit beginnt mit der ersten Zahlung. Lieferung in einer Woche: am Montag nach Eingang der vollständigen Unterlagen.'],
      ['Prüfung und Restzahlung', 'Sie prüfen die Arbeit und zahlen dann die restlichen 50 %.']
    ],
    info: [
      ['Zahlung und Rechnung', 'Zwei Online-Zahlungen pro Artikel über Lemon Squeezy, eine Plattform mit internationaler Rechnungsstellung: auch für Unternehmen im Ausland geeignet. Für jede Zahlung erhalten Sie eine Rechnung.'],
      ['Dateien öffnen und drucken', 'Keine Software erforderlich. DWG/DXF- und PDF-Dateien öffnen sich mit jedem CAD-Viewer und werden im Maßstab 1:1 gedruckt. Beim ersten Öffnen und Drucken helfe ich Ihnen.'],
      ['Änderungen und Varianten', 'Werden vorab vereinbart. Kleine Ergänzungen +30 % des Modellpreises; Varianten mit neuer Konstruktion oder Entwicklung +50-70 %.'],
      ['Design', 'Wird neben der Schnitttechnik auch Design benötigt, wird es nach Stunden abgerechnet oder für die ganze Kollektion vereinbart.']
    ]
  },
  software: {
    eyebrow: 'Für die Schnitttechnik im eigenen Haus',
    h1: 'Leonardo Pattern Design',
    p1: 'Die von mir entwickelte Schnitttechnik-Software für Lederwaren. Sie wird auf ZWCAD (2024-2027) und AutoCAD (2018 und 2024-2027) installiert und fügt über 350 Befehle hinzu.',
    features: [
      ['Formen und Abwicklungen', 'Teile, Streifen, Seitenteile, Böden, Faltenbälge, Futter; Abwicklung von 3D-Flächen.'],
      ['Knipse und Konturen', 'Knipse in verschiedenen Formen und Prüfung offener oder doppelter Konturen.'],
      ['Nesting', 'Anordnung der Teile auf der Haut, mit vergleichbaren Strategien.'],
      ['Verbrauch und BOM', 'Berechnung von Verbrauch und Kosten, Export nach Excel, CSV und HTML.'],
      ['Zuschnitt', 'Dateien für ATOM-, AAMA- und Gerber-Maschinen und -Plotter.'],
      ['KI-Schnitttechniker', 'Ein im CAD integrierter Assistent, der die Zeichnung liest und vor jeder Änderung um Bestätigung bittet.']
    ],
    price: 'Monatliche Lizenz ohne Bindung, 199,99 € zzgl. MwSt. Kostenlose Testversion.',
    cta: 'Leonardo auf guasqui.it entdecken',
    boxH: 'Service und Software sind unabhängig',
    boxP: 'Um meine Schnitte zu erhalten, brauchen Sie Leonardo nicht. Die Software ist für alle, die Modelle im eigenen Haus entwickeln möchten.'
  },
  contact: {
    eyebrow: 'Kontakt',
    h1: 'Senden Sie mir Ihr erstes Modell: Ich antworte mit Klasse, Preis und Liefertermin.',
    lead: 'Schreiben Sie mir und hängen Sie das Datenblatt mit Ansichten und Maßen an.',
    portfolio: 'Portfolio und Referenzen',
    checkH: 'Was Sie der Anfrage beifügen sollten'
  }
};
