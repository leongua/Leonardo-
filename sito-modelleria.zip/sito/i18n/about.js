// Pagina "Chi sono", ripresa dal portfolio da modellista freelance
module.exports = {
  it: {
    nav: 'Chi sono', title: 'Chi sono', eyebrow: 'Chi sono',
    h1: 'Oltre il cartamodello: ingegneria della produzione.',
    p1: 'Sono modellista e responsabile tecnico in una manifattura toscana di pelletteria di lusso, dove dal 2017 seguo campionario e industrializzazione. Per questo lavoro ho sviluppato da zero Leonardo Pattern Design, il software CAD che oggi conta oltre 350 comandi per la pelletteria.',
    p2: 'La mia specialità è trasformare il design di una borsa in un modello pronto per la produzione: cartamodello tecnico, nesting ottimizzato, analisi dei costi dei materiali e industrializzazione.',
    servicesH: 'Servizi',
    services: [
      ['Modelleria e sviluppo', 'Cartamodelli di borse e piccola pelletteria, dal disegno tecnico al modello pronto per il taglio.'],
      ['Industrializzazione', 'Preparazione del modello per la produzione in serie: sequenze di lavorazione, file per il taglio, tolleranze.'],
      ['Consulenza di produzione', 'Supporto tecnico nel passaggio dal prototipo alla produzione.'],
      ['Ottimizzazione dei costi', 'Analisi di distinta base, consumi e scarti per ridurre i costi senza perdere qualità.'],
      ['Formazione', 'Formazione tecnica su CAD e modelleria per team di design e produzione.'],
      ['Consulenza internazionale', 'Supporto ai brand esteri che producono o vogliono produrre in Italia.']
    ],
    skillsH: 'Competenze',
    skills: ['ZWCAD / AutoCAD', 'Modelleria borse', 'Nesting e taglio CAM', 'Analisi costi e DIBA', 'Industrializzazione', 'VB.NET / AutoLISP / Python']
  },
  en: {
    nav: 'About', title: 'About me', eyebrow: 'About me',
    h1: 'Beyond the pattern: production engineering.',
    p1: 'I am a pattern maker and technical manager at a Tuscan luxury leather goods manufacturer, where I have handled sampling and industrialisation since 2017. For this work I built Leonardo Pattern Design from scratch: the CAD software that now has over 350 commands for leather goods.',
    p2: 'My speciality is turning a bag design into a production-ready model: technical pattern, optimised nesting, material cost analysis and industrialisation.',
    servicesH: 'Services',
    services: [
      ['Pattern making and development', 'Patterns for bags and small leather goods, from technical drawing to cutting-ready model.'],
      ['Industrialisation', 'Preparing the model for series production: work sequences, cutting files, tolerances.'],
      ['Production consulting', 'Technical support in the move from prototype to production.'],
      ['Cost optimisation', 'Analysis of BOM, consumption and waste to cut costs without losing quality.'],
      ['Training', 'Technical training on CAD and pattern making for design and production teams.'],
      ['International consulting', 'Support for foreign brands that produce, or want to produce, in Italy.']
    ],
    skillsH: 'Skills',
    skills: ['ZWCAD / AutoCAD', 'Bag pattern making', 'Nesting and CAM cutting', 'Cost analysis and BOM', 'Industrialisation', 'VB.NET / AutoLISP / Python']
  },
  fr: {
    nav: 'À propos', title: 'À propos', eyebrow: 'À propos',
    h1: 'Au-delà du patronage : l’ingénierie de la production.',
    p1: 'Je suis modéliste et responsable technique dans une manufacture toscane de maroquinerie de luxe, où je m’occupe des prototypes et de l’industrialisation depuis 2017. Pour ce travail, j’ai développé de zéro Leonardo Pattern Design, le logiciel de CAO qui compte aujourd’hui plus de 350 commandes pour la maroquinerie.',
    p2: 'Ma spécialité : transformer le design d’un sac en un modèle prêt pour la production, avec patronage technique, placement optimisé, analyse des coûts matières et industrialisation.',
    servicesH: 'Services',
    services: [
      ['Modélisme et développement', 'Patronages de sacs et de petite maroquinerie, du dessin technique au modèle prêt à la coupe.'],
      ['Industrialisation', 'Préparation du modèle pour la production en série : gammes de montage, fichiers de coupe, tolérances.'],
      ['Conseil en production', 'Accompagnement technique du prototype à la production.'],
      ['Optimisation des coûts', 'Analyse de la nomenclature, des consommations et des chutes pour réduire les coûts sans perdre en qualité.'],
      ['Formation', 'Formation technique en CAO et modélisme pour les équipes de design et de production.'],
      ['Conseil international', 'Accompagnement des marques étrangères qui produisent, ou souhaitent produire, en Italie.']
    ],
    skillsH: 'Compétences',
    skills: ['ZWCAD / AutoCAD', 'Modélisme sacs', 'Placement et coupe CAM', 'Analyse des coûts et BOM', 'Industrialisation', 'VB.NET / AutoLISP / Python']
  },
  de: {
    nav: 'Über mich', title: 'Über mich', eyebrow: 'Über mich',
    h1: 'Mehr als ein Schnitt: Produktionstechnik.',
    p1: 'Ich bin Schnitttechniker und technischer Leiter in einer toskanischen Manufaktur für Luxuslederwaren, wo ich seit 2017 Musterentwicklung und Industrialisierung betreue. Dafür habe ich Leonardo Pattern Design von Grund auf entwickelt: die CAD-Software, die heute über 350 Befehle für Lederwaren bietet.',
    p2: 'Meine Spezialität ist es, aus einem Taschendesign ein produktionsreifes Modell zu machen: technischer Schnitt, optimiertes Nesting, Materialkostenanalyse und Industrialisierung.',
    servicesH: 'Leistungen',
    services: [
      ['Schnitttechnik und Entwicklung', 'Schnitte für Taschen und Kleinlederwaren, von der technischen Zeichnung bis zum zuschnittfertigen Modell.'],
      ['Industrialisierung', 'Vorbereitung des Modells für die Serienfertigung: Arbeitsfolgen, Zuschnittdateien, Toleranzen.'],
      ['Produktionsberatung', 'Technische Begleitung vom Prototyp zur Produktion.'],
      ['Kostenoptimierung', 'Analyse von Stückliste, Verbrauch und Verschnitt, um Kosten ohne Qualitätsverlust zu senken.'],
      ['Schulung', 'Technische Schulungen zu CAD und Schnitttechnik für Design- und Produktionsteams.'],
      ['Internationale Beratung', 'Unterstützung für ausländische Marken, die in Italien produzieren oder produzieren möchten.']
    ],
    skillsH: 'Kompetenzen',
    skills: ['ZWCAD / AutoCAD', 'Taschen-Schnitttechnik', 'Nesting und CAM-Zuschnitt', 'Kostenanalyse und BOM', 'Industrialisierung', 'VB.NET / AutoLISP / Python']
  },
  es: {
    nav: 'Sobre mí', title: 'Sobre mí', eyebrow: 'Sobre mí',
    h1: 'Más allá del patrón: ingeniería de la producción.',
    p1: 'Soy patronista y responsable técnico en una manufactura toscana de marroquinería de lujo, donde desde 2017 llevo el muestrario y la industrialización. Para este trabajo desarrollé desde cero Leonardo Pattern Design, el software CAD que hoy cuenta con más de 350 comandos para marroquinería.',
    p2: 'Mi especialidad es convertir el diseño de un bolso en un modelo listo para producción: patrón técnico, nesting optimizado, análisis de costes de materiales e industrialización.',
    servicesH: 'Servicios',
    services: [
      ['Patronaje y desarrollo', 'Patrones de bolsos y pequeña marroquinería, del dibujo técnico al modelo listo para el corte.'],
      ['Industrialización', 'Preparación del modelo para la producción en serie: secuencias de trabajo, archivos de corte, tolerancias.'],
      ['Consultoría de producción', 'Apoyo técnico en el paso del prototipo a la producción.'],
      ['Optimización de costes', 'Análisis del escandallo, consumos y mermas para reducir costes sin perder calidad.'],
      ['Formación', 'Formación técnica en CAD y patronaje para equipos de diseño y producción.'],
      ['Consultoría internacional', 'Apoyo a marcas extranjeras que producen, o quieren producir, en Italia.']
    ],
    skillsH: 'Competencias',
    skills: ['ZWCAD / AutoCAD', 'Patronaje de bolsos', 'Nesting y corte CAM', 'Análisis de costes y BOM', 'Industrialización', 'VB.NET / AutoLISP / Python']
  },
  zh: {
    nav: '关于我', title: '关于我', eyebrow: '关于我',
    h1: '不止于纸格：生产工程。',
    p1: '我是托斯卡纳一家奢侈皮具工厂的纸格师兼技术负责人，自 2017 年起负责样品开发与工业化生产。为此我从零开发了 Leonardo Pattern Design，这款 CAD 软件如今拥有 350 多条皮具专用命令。',
    p2: '我的专长是把手袋设计转化为可投产的款式：技术纸格、优化排料、材料成本分析与工业化。',
    servicesH: '服务',
    services: [
      ['纸格制版与开发', '手袋与小皮具纸格，从技术图到可直接裁切的版型。'],
      ['工业化', '为批量生产准备版型：工序、裁切文件、公差。'],
      ['生产咨询', '从样品到量产的技术支持。'],
      ['成本优化', '分析物料清单、用料与损耗，在不降低品质的前提下降低成本。'],
      ['培训', '为设计和生产团队提供 CAD 与纸格制版技术培训。'],
      ['国际咨询', '支持在意大利生产或希望在意大利生产的海外品牌。']
    ],
    skillsH: '专业技能',
    skills: ['ZWCAD / AutoCAD', '手袋纸格制版', '排料与 CAM 裁切', '成本分析与 BOM', '工业化', 'VB.NET / AutoLISP / Python']
  },
  ar: {
    nav: 'من أنا', title: 'من أنا', eyebrow: 'من أنا',
    h1: 'أبعد من الباترون: هندسة الإنتاج.',
    p1: 'أنا مصمم باترونات ومسؤول تقني في مصنع توسكاني للمصنوعات الجلدية الفاخرة، حيث أتولى منذ عام 2017 تطوير العينات والتصنيع. ولأجل هذا العمل طوّرت من الصفر برنامج Leonardo Pattern Design، وهو برنامج تصميم بمساعدة الحاسوب يضم اليوم أكثر من 350 أمرًا مخصصًا للمصنوعات الجلدية.',
    p2: 'تخصصي هو تحويل تصميم الحقيبة إلى نموذج جاهز للإنتاج: باترون تقني، وتوزيع أمثل للقطع، وتحليل تكاليف المواد، والتصنيع.',
    servicesH: 'الخدمات',
    services: [
      ['تصميم الباترونات والتطوير', 'باترونات الحقائب والمصنوعات الجلدية الصغيرة، من الرسم التقني إلى نموذج جاهز للقص.'],
      ['التصنيع', 'تجهيز النموذج للإنتاج المتسلسل: مراحل العمل وملفات القص والتفاوتات المسموحة.'],
      ['استشارات الإنتاج', 'دعم تقني في الانتقال من النموذج الأولي إلى الإنتاج.'],
      ['تحسين التكاليف', 'تحليل قائمة المواد والاستهلاك والهدر لخفض التكاليف دون المساس بالجودة.'],
      ['التدريب', 'تدريب تقني على برامج التصميم وصناعة الباترونات لفرق التصميم والإنتاج.'],
      ['استشارات دولية', 'دعم العلامات الأجنبية التي تنتج في إيطاليا أو ترغب في ذلك.']
    ],
    skillsH: 'المهارات',
    skills: ['ZWCAD / AutoCAD', 'باترونات الحقائب', 'توزيع القطع والقص الآلي', 'تحليل التكاليف وقائمة المواد', 'التصنيع', 'VB.NET / AutoLISP / Python']
  }
};
