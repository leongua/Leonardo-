// Seconda metà di "Chi sono": il portfolio da sviluppatore (guasqui.it/portfolio.html)
module.exports = {
  it: {
    h: 'Modellista e sviluppatore',
    p: 'Dal 2024 lavoro anche come freelance nello sviluppo di software su misura, intelligenza artificiale e automazione per il manifatturiero. Questi sono i progetti più vicini alla pelletteria.',
    projects: [
      ['Patronistica digitale CAD', 'Il sistema di modelleria per pelletteria integrato nel flusso produttivo e nelle macchine da taglio, da cui è nato Leonardo.'],
      ['Ricerca geometrica negli archivi CAD', 'Trova nell\'archivio le sagome che corrispondono a un modello, per riusare pezzi già sviluppati.'],
      ['Calcolatori e report automatici', 'Consumi di materiale e report di produzione generati da Excel e CSV.'],
      ['Assistente IA sui documenti aziendali', 'Domande in linguaggio naturale su DDT, specifiche e cataloghi, anche in locale.']
    ],
    more: 'Portfolio completo da sviluppatore'
  },
  en: {
    h: 'Pattern maker and developer',
    p: 'Since 2024 I have also worked freelance on custom software, artificial intelligence and automation for manufacturing. These are the projects closest to leather goods.',
    projects: [
      ['Digital CAD pattern system', 'The leather goods pattern system integrated into the production flow and cutting machines, from which Leonardo was born.'],
      ['Geometric search in CAD archives', 'Finds the shapes in the archive that match a model, to reuse pieces already developed.'],
      ['Automatic calculators and reports', 'Material consumption and production reports generated from Excel and CSV.'],
      ['AI assistant on company documents', 'Natural-language questions on delivery notes, specifications and catalogues, even fully on-premise.']
    ],
    more: 'Full developer portfolio'
  },
  fr: {
    h: 'Modéliste et développeur',
    p: 'Depuis 2024, je travaille aussi en indépendant sur des logiciels sur mesure, l’intelligence artificielle et l’automatisation pour l’industrie. Voici les projets les plus proches de la maroquinerie.',
    projects: [
      ['Patronage numérique CAO', 'Le système de modélisme pour la maroquinerie intégré au flux de production et aux machines de coupe, d’où est né Leonardo.'],
      ['Recherche géométrique dans les archives CAO', 'Retrouve dans l’archive les formes correspondant à un modèle, pour réutiliser des pièces déjà développées.'],
      ['Calculateurs et rapports automatiques', 'Consommations de matière et rapports de production générés à partir d’Excel et de CSV.'],
      ['Assistant IA sur les documents de l’entreprise', 'Questions en langage naturel sur bons de livraison, spécifications et catalogues, même en local.']
    ],
    more: 'Portfolio complet de développeur'
  },
  de: {
    h: 'Schnitttechniker und Entwickler',
    p: 'Seit 2024 arbeite ich außerdem freiberuflich an maßgeschneiderter Software, künstlicher Intelligenz und Automatisierung für die Fertigung. Dies sind die Projekte, die den Lederwaren am nächsten sind.',
    projects: [
      ['Digitale CAD-Schnitttechnik', 'Das Schnittsystem für Lederwaren, integriert in den Produktionsablauf und die Zuschnittmaschinen, aus dem Leonardo entstanden ist.'],
      ['Geometrische Suche in CAD-Archiven', 'Findet im Archiv die Formen, die zu einem Modell passen, um bereits entwickelte Teile wiederzuverwenden.'],
      ['Automatische Rechner und Berichte', 'Materialverbrauch und Produktionsberichte aus Excel und CSV.'],
      ['KI-Assistent für Firmendokumente', 'Fragen in natürlicher Sprache zu Lieferscheinen, Spezifikationen und Katalogen, auch lokal.']
    ],
    more: 'Vollständiges Entwickler-Portfolio'
  },
  es: {
    h: 'Patronista y desarrollador',
    p: 'Desde 2024 también trabajo como freelance en software a medida, inteligencia artificial y automatización para la industria. Estos son los proyectos más cercanos a la marroquinería.',
    projects: [
      ['Patronaje digital CAD', 'El sistema de patronaje para marroquinería integrado en el flujo de producción y en las máquinas de corte, del que nació Leonardo.'],
      ['Búsqueda geométrica en archivos CAD', 'Encuentra en el archivo las formas que coinciden con un modelo, para reutilizar piezas ya desarrolladas.'],
      ['Calculadoras e informes automáticos', 'Consumos de material e informes de producción generados desde Excel y CSV.'],
      ['Asistente IA sobre documentos de empresa', 'Preguntas en lenguaje natural sobre albaranes, especificaciones y catálogos, también en local.']
    ],
    more: 'Portfolio completo de desarrollador'
  },
  zh: {
    h: '纸格师兼开发者',
    p: '自 2024 年起，我也以自由职业者身份为制造业开发定制软件、人工智能和自动化方案。以下是与皮具最相关的项目。',
    projects: [
      ['数字化 CAD 纸格系统', '融入生产流程和裁床的皮具纸格系统，Leonardo 由此诞生。'],
      ['CAD 档案几何检索', '在档案中查找与某款式相匹配的版型，重复利用已开发的部件。'],
      ['自动计算器与报表', '从 Excel 和 CSV 生成用料与生产报表。'],
      ['企业文档 AI 助手', '用自然语言查询送货单、规格书和产品目录，也可本地部署。']
    ],
    more: '完整开发者作品集'
  },
  ar: {
    h: 'مصمم باترونات ومطوّر',
    p: 'منذ عام 2024 أعمل أيضًا بشكل مستقل على برمجيات مخصصة والذكاء الاصطناعي والأتمتة للقطاع الصناعي. هذه هي المشاريع الأقرب إلى المصنوعات الجلدية.',
    projects: [
      ['نظام باترونات رقمي بالحاسوب', 'نظام الباترونات للمصنوعات الجلدية المدمج في سير الإنتاج وآلات القص، ومنه وُلد Leonardo.'],
      ['البحث الهندسي في أرشيف التصاميم', 'يعثر في الأرشيف على الأشكال المطابقة لنموذج ما، لإعادة استخدام قطع مطوّرة مسبقًا.'],
      ['حاسبات وتقارير تلقائية', 'استهلاك المواد وتقارير الإنتاج من ملفات Excel وCSV.'],
      ['مساعد ذكاء اصطناعي لوثائق الشركة', 'أسئلة باللغة الطبيعية حول إشعارات التسليم والمواصفات والكتالوجات، حتى محليًا.']
    ],
    more: 'ملف الأعمال الكامل كمطوّر'
  }
};
