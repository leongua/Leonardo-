// Genera il sito statico in public/<lingua>/ a partire dai testi in i18n/.
// Uso: node build.js
const fs = require('fs');
const path = require('path');

const LANGS = ['it', 'en', 'fr', 'de', 'es', 'zh', 'ar'];
const OUT = path.join(__dirname, 'public');
const EMAIL = 'leonardo@guasqui.it';
const LEONARDO_URL = 'https://www.guasqui.it';
const PORTFOLIO_URL = 'https://www.guasqui.it/portfolio.html';

// Standard delle classi: lettera e prezzo per modello (IVA esclusa)
const CLASSES = [
  ['A', '250 €'], ['B', '300 €'], ['C', '350 €'], ['D', '400 €'],
  ['E', '450 €'], ['F', '550 €'], ['G', '650 €'], ['H', '800 €']
];

// Schede tecniche di esempio e classe indicativa
const EXAMPLES = [
  ['scheda-01.jpg', 'D'], ['scheda-02.png', 'D'], ['scheda-03.png', 'D'],
  ['scheda-04.png', 'E'], ['scheda-05.png', 'F'], ['scheda-06.png', 'F'], ['scheda-07.png', 'D']
];

const PAGES = [
  ['home', 'index.html'], ['about', 'chi-sono.html'], ['classes', 'classi.html'], ['sheet', 'scheda-tecnica.html'],
  ['process', 'come-lavoro.html'], ['software', 'software.html'], ['contact', 'contatti.html']
];
const file = (key) => PAGES.find((p) => p[0] === key)[1];

const T = {};
const ABOUT = require('./i18n/about.js');
const ABOUT_DEV = require('./i18n/about-dev.js');
for (const l of LANGS) {
  T[l] = require(`./i18n/${l}.js`);
  T[l].about = ABOUT[l];
  T[l].aboutDev = ABOUT_DEV[l];
  T[l].nav.about = ABOUT[l].nav;
  T[l].titles.about = ABOUT[l].title;
}

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const mailto = (subject) => `mailto:${EMAIL}?subject=${encodeURIComponent(subject)}`;

function fonts(t) {
  let fam = 'family=Playfair+Display:wght@600;700;800&family=Lora:wght@400;500;600';
  if (t.lang === 'zh') fam += '&family=Noto+Sans+SC:wght@400;500;700';
  if (t.lang === 'ar') fam += '&family=Noto+Sans+Arabic:wght@400;500;700';
  return `<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?${fam.replace(/&/g, '&amp;')}&amp;display=swap" rel="stylesheet">`;
}

function header(t, key) {
  const nav = PAGES.map(([k, f]) =>
    `<a href="${f}"${k === key ? ' aria-current="page"' : ''}>${esc(t.nav[k])}</a>`).join('\n');
  const langs = LANGS.map((l) =>
    `<a href="../${l}/${file(key)}" lang="${l}" hreflang="${l}" title="${esc(T[l].name)}"${l === t.lang ? ' aria-current="true"' : ''}>${T[l].label}</a>`).join('');
  return `<header class="site-header">
<div class="wrap">
<a class="brand" href="index.html">LEONARDO GUASQUI <span>· ${esc(t.brandSub)}</span></a>
<button class="menu-toggle" type="button" aria-expanded="false">${esc(t.menu)}</button>
<nav class="nav" aria-label="${esc(t.menu)}">
${nav}
</nav>
<div class="langs">${langs}</div>
</div>
</header>`;
}

function footer(t) {
  return `<footer class="site-footer">
<div class="wrap">
<div>${esc(t.footerLoc)}</div>
<div><a href="${mailto(t.mailSubject)}">${EMAIL}</a> · <a href="${LEONARDO_URL}">guasqui.it</a></div>
<div>${esc(t.footerNote)}</div>
</div>
</footer>`;
}

function page(t, key, body) {
  const alt = LANGS.map((l) => `<link rel="alternate" hreflang="${l}" href="../${l}/${file(key)}">`).join('\n');
  return `<!doctype html>
<html lang="${t.lang}" dir="${t.dir}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(t.titles[key])} – Leonardo Guasqui</title>
<meta name="description" content="${esc(t.metaDesc)}">
${alt}
${fonts(t)}
<link rel="stylesheet" href="../css/style.css">
<script src="../js/menu.js" defer></script>
</head>
<body>
${header(t, key)}
<main>
${body}
</main>
${footer(t)}
</body>
</html>
`;
}

function ctaBand(t) {
  return `<section class="cta-final"><div class="wrap stack">
<h2>${esc(t.contact.h1)}</h2>
<div class="row"><a class="btn btn-gold" href="${mailto(t.mailSubject)}">${esc(t.ctaQuote)}</a>
<a class="btn btn-ghost" href="${file('about')}">${esc(t.contact.portfolio)}</a></div>
</div></section>`;
}

function classCards(t) {
  return `<div class="classes">` + CLASSES.map(([letter, price], i) => {
    const [name, desc, ex] = t.classes.list[i];
    const meter = CLASSES.map((_, j) => `<i${j <= i ? ' class="on"' : ''}></i>`).join('');
    const tone = i >= 7 ? ' l3' : i >= 4 ? ' l2' : '';
    return `<article class="class-card${i === 7 ? ' top' : ''}" id="classe-${letter.toLowerCase()}">
<div class="class-head"><div class="class-id"><div class="letter${tone}">${letter}</div><h3 class="class-name">${esc(name)}</h3></div><div class="price">${price}</div></div>
<div class="meter" role="img" aria-label="${esc(t.classes.level.replace('{n}', i + 1))}">${meter}</div>
<p>${esc(desc)}</p>
<div class="ex"><strong>${esc(t.classes.examples)}</strong> ${esc(ex)}</div>
</article>`;
  }).join('\n') + `</div>`;
}

function diagram(t) {
  const d = t.sheet.diagram;
  return `<svg viewBox="0 0 560 330" role="img" aria-label="${esc(d.aria)}" style="width:100%;height:auto" direction="ltr">
<g fill="none" stroke="#D4D4D8" stroke-width="2"><path d="M110 120 Q190 20 270 120"/><rect x="70" y="120" width="240" height="160" rx="10"/><path d="M70 135 L310 135 L310 200 Q190 225 70 200 Z"/><rect x="175" y="196" width="30" height="22" rx="3"/><rect x="420" y="120" width="80" height="160" rx="8"/><path d="M460 120 L460 90"/></g>
<g fill="none" stroke="#D4D4D8" stroke-width="1" stroke-dasharray="4 4"><rect x="78" y="143" width="224" height="129" rx="6"/><rect x="428" y="128" width="64" height="144" rx="4"/></g>
<g stroke="#C9A961" stroke-width="1.5"><path d="M70 300 L310 300 M70 294 L70 306 M310 294 L310 306"/><path d="M40 120 L40 280 M34 120 L46 120 M34 280 L46 280"/><path d="M335 70 L335 120 M329 70 L341 70 M329 120 L341 120"/><path d="M420 300 L500 300 M420 294 L420 306 M500 294 L500 306"/></g>
<g fill="#C9A961" font-family="Lora, 'Noto Sans SC', 'Noto Sans Arabic', serif" font-size="14" font-weight="600"><text x="190" y="322" text-anchor="middle">${esc(d.w)}</text><text x="28" y="200" text-anchor="middle" transform="rotate(-90 28 200)">${esc(d.h)}</text><text x="348" y="99">${esc(d.drop)}</text><text x="460" y="322" text-anchor="middle">${esc(d.d)}</text></g>
<g fill="#A0A0A8" font-family="Lora, 'Noto Sans SC', 'Noto Sans Arabic', serif" font-size="13"><text x="190" y="30" text-anchor="middle">${esc(d.front)}</text><text x="460" y="30" text-anchor="middle">${esc(d.side)}</text></g>
</svg>`;
}

function checklist(t) {
  return `<ul class="checklist">` + t.sheet.items.map(([h, p]) =>
    `<li><h3>${esc(h)}</h3><p>${esc(p)}</p></li>`).join('') + `</ul>`;
}

const bodies = {
  about: (t) => `<section class="hero"><div class="wrap">
<div class="eyebrow">${esc(t.about.eyebrow)}</div>
<h1>${esc(t.about.h1)}</h1>
<p class="lead">${esc(t.about.p1)}</p>
<p class="lead">${esc(t.about.p2)}</p>
<ul class="chips" aria-label="${esc(t.about.skillsH)}">${t.about.skills.map((s) => `<li>${esc(s)}</li>`).join('')}</ul>
</div></section>
<section class="alt"><div class="wrap stack" style="gap:32px">
<h2>${esc(t.about.servicesH)}</h2>
<div class="grid3">${t.about.services.map(([h, p]) => `<div class="card"><h3>${esc(h)}</h3><p>${esc(p)}</p></div>`).join('')}</div>
</div></section>
<section><div class="wrap stack" style="gap:32px">
<div class="stack"><div class="eyebrow">guasqui.it</div><h2>${esc(t.aboutDev.h)}</h2><p class="lead">${esc(t.aboutDev.p)}</p></div>
<div class="grid2">${t.aboutDev.projects.map(([h, p], i) => `<div class="card project"><span class="num">0${i + 1}</span><h3>${esc(h)}</h3><p>${esc(p)}</p></div>`).join('')}</div>
<div class="row"><a class="btn btn-gold" href="${PORTFOLIO_URL}">${esc(t.aboutDev.more)}</a><a class="btn btn-ghost" href="${file('software')}">Leonardo Pattern Design</a></div>
</div></section>
${ctaBand(t)}`,
  home: (t) => `<section class="hero"><div class="wrap">
<div class="eyebrow">${esc(t.home.eyebrow)}</div>
<h1>${esc(t.home.h1)}</h1>
<p class="lead">${esc(t.home.lead)}</p>
<div class="row"><a class="btn btn-gold" href="${mailto(t.mailSubject)}">${esc(t.ctaQuote)}</a><a class="btn btn-ghost" href="${file('classes')}">${esc(t.home.seeClasses)}</a></div>
<div class="stats">${t.home.stats.map(([b, s]) => `<div class="stat"><b>${esc(b)}</b><span>${esc(s)}</span></div>`).join('')}</div>
</div></section>
<section><div class="wrap stack" style="gap:32px">
<h2>${esc(t.home.deliverH)}</h2>
<div class="row">${t.home.deliver.map(([h, p]) => `<div class="card"><h3>${esc(h)}</h3><p>${esc(p)}</p></div>`).join('')}</div>
</div></section>
<section class="alt"><div class="wrap stack" style="gap:32px">
<h2>${esc(t.home.nextH)}</h2>
<div class="row">${t.home.next.map(([h, p], i) => `<div class="card"><h3>${esc(h)}</h3><p>${esc(p)}</p><a href="${file(['classes', 'sheet', 'process'][i])}">${esc(t.home.open)} →</a></div>`).join('')}</div>
</div></section>
${ctaBand(t)}`,

  classes: (t) => `<section><div class="wrap stack" style="gap:28px">
<div class="stack"><div class="eyebrow">${esc(t.classes.eyebrow)}</div><h1>${esc(t.classes.h1)}</h1><p class="lead">${esc(t.classes.lead)}</p></div>
${classCards(t)}
<h2 style="margin-top:24px">${esc(t.classes.extrasH)}</h2>
<div class="extras">${t.classes.extras.map(([s, b, d]) => `<div><small>${esc(s)}</small><b>${esc(b)}</b><span>${esc(d)}</span></div>`).join('')}</div>
<div class="banner"><div class="stack"><h3>${esc(t.classes.designH)}</h3><p>${esc(t.classes.designP)}</p></div>
<a class="btn btn-gold" href="${mailto(t.classes.designSubject)}">${esc(t.classes.designCta)}</a></div>
</div></section>
${ctaBand(t)}`,

  sheet: (t) => `<section><div class="wrap stack" style="gap:32px">
<div class="stack"><div class="eyebrow">${esc(t.sheet.eyebrow)}</div><h1>${esc(t.sheet.h1)}</h1><p class="lead">${esc(t.sheet.lead)}</p></div>
<div class="sheet-grid"><figure>${diagram(t)}<figcaption>${esc(t.sheet.caption)}</figcaption></figure>${checklist(t)}</div>
</div></section>
<section class="alt"><div class="wrap stack" style="gap:28px">
<div class="stack"><h2>${esc(t.sheet.examplesH)}</h2><p class="lead">${esc(t.sheet.examplesLead)}</p></div>
<div class="gallery">${EXAMPLES.map(([f, c], i) => `<figure class="example" style="margin:0">
<a class="thumb" href="../img/esempi/${f}" target="_blank" rel="noopener" aria-label="${esc(t.sheet.enlarge)}"><img src="../img/esempi/${f}" alt="${esc(t.sheet.ex[i])}" loading="lazy"></a>
<figcaption class="info"><a class="tag" href="${file('classes')}#classe-${c.toLowerCase()}">${esc(t.sheet.classTag.replace('{c}', c))}</a><p>${esc(t.sheet.ex[i])}</p></figcaption>
</figure>`).join('\n')}</div>
</div></section>
${ctaBand(t)}`,

  process: (t) => `<section><div class="wrap stack" style="gap:32px">
<div class="stack"><div class="eyebrow">${esc(t.process.eyebrow)}</div><h1>${esc(t.process.h1)}</h1></div>
<div class="row">${t.process.steps.map(([h, p], i) => `<div class="card"><div class="step-n">${i + 1}</div><h3>${esc(h)}</h3><p>${esc(p)}</p></div>`).join('')}</div>
</div></section>
<section class="alt"><div class="wrap"><div class="row">${t.process.info.map(([h, p]) => `<div class="card"><h3>${esc(h)}</h3><p>${esc(p)}</p></div>`).join('')}</div></div></section>
${ctaBand(t)}`,

  software: (t) => `<section><div class="wrap stack" style="gap:32px">
<div class="stack"><div class="eyebrow">${esc(t.software.eyebrow)}</div><h1>${esc(t.software.h1)}</h1><p class="lead">${esc(t.software.p1)}</p></div>
<div class="row">${t.software.features.map(([h, p]) => `<div class="card"><h3>${esc(h)}</h3><p>${esc(p)}</p></div>`).join('')}</div>
<p style="font-size:18px">${esc(t.software.price)}</p>
<div><a class="btn btn-gold" href="${LEONARDO_URL}">${esc(t.software.cta)}</a></div>
<div class="banner"><div class="stack"><h3>${esc(t.software.boxH)}</h3><p>${esc(t.software.boxP)}</p></div></div>
</div></section>`,

  contact: (t) => `<section class="hero"><div class="wrap">
<div class="eyebrow">${esc(t.contact.eyebrow)}</div>
<h1>${esc(t.contact.h1)}</h1>
<p class="lead">${esc(t.contact.lead)}</p>
<div class="row"><a class="btn btn-gold" href="${mailto(t.mailSubject)}">${EMAIL}</a><a class="btn btn-ghost" href="${file('about')}">${esc(t.contact.portfolio)}</a></div>
</div></section>
<section><div class="wrap stack" style="gap:28px"><h2>${esc(t.contact.checkH)}</h2>${checklist(t)}</div></section>`
};

function rootIndex() {
  const links = LANGS.map((l) => `<li><a href="${l}/index.html" lang="${l}" hreflang="${l}">${T[l].name}</a></li>`).join('\n');
  return `<!doctype html>
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Leonardo Guasqui – Modelleria</title>
<link rel="stylesheet" href="css/style.css">
<script>
(function(){var ok=${JSON.stringify(LANGS)};var l=((navigator.languages&&navigator.languages[0])||navigator.language||'it').slice(0,2).toLowerCase();location.replace((ok.indexOf(l)>=0?l:'it')+'/index.html');})();
</script>
</head>
<body>
<main class="wrap" style="padding:80px 28px"><h1>Leonardo Guasqui</h1><ul>${links}</ul></main>
</body>
</html>
`;
}

for (const l of LANGS) {
  const t = T[l];
  const dir = path.join(OUT, l);
  fs.mkdirSync(dir, { recursive: true });
  for (const [key, f] of PAGES) fs.writeFileSync(path.join(dir, f), page(t, key, bodies[key](t)));
}
fs.writeFileSync(path.join(OUT, 'index.html'), rootIndex());
console.log(`Sito generato: ${LANGS.length} lingue × ${PAGES.length} pagine in ${OUT}`);
